<script>
  const variable = {
    logoImage : 'http://www.hdmool.com/images/logo-new.png',
    defaultHead : './static/images/avatar.jpg',
    emptyImage : './static/images/empty.png',
  };

  export default {
    variable
  }
</script>
